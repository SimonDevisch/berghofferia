'use strict';

(function() {

    const startSpel = function() {
        document.querySelector('.gamescreen').innerHTML = '<img src="./images/balie1.png" alt="Balie met mensen en kassa">';
    }

    const startButton = document.querySelector('.startbutton');
    startButton.addEventListener('click', startSpel);

})();