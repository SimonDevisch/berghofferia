'use strict';

(function() {

    const startSpel = function() {
        const startScreen = document.querySelector('.startscreen');
        startScreen.innerHTML = '<img src="./images/start_dag.png" alt="Balie met mensen en kassa">';
        startScreen.classList.add('introTekst');
        startButton.textContent = 'Herstart de game';
        setTimeout(function() {
            startScreen.style.opacity = '0';
        }, 5000);
        const firstOrderScreen = document.querySelector('.first_orderscreen');
        firstOrderScreen.innerHTML = '<img src="./images/eerste_order.png" alt="Balie met mensen en kassa">';
        setTimeout(function() {
            startScreen.classList.add('hidden');
            firstOrderScreen.classList.remove('hidden');
        }, 5000);
    }

    const startButton = document.querySelector('.startbutton');
    startButton.addEventListener('click', startSpel);


})();